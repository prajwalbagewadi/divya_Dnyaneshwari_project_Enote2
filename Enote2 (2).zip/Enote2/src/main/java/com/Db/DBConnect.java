//package com.Db;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//public class DBConnect {
//	
//	private static Connection conn;
//	public static Connection getConn()
//	{
//		try {
//			
//			if(conn==null)
//			{
//				Class.forName("com.mysql.cj.jdbc.Driver");
//				conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/enotes2","root","12345");
//			}
//			
//			} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//		return conn;
//
//}
//}

package com.Db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
    private static Connection conn;

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Load MySQL Driver
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enotes2", "root", "12345");
                System.out.println("✅ Database connected successfully!");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("❌ JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ Database connection failed!");
            e.printStackTrace();
        }
        return conn;
    }
}

