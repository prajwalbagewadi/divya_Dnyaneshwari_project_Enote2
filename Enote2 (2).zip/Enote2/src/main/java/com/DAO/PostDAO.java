package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.User.Post;

public class PostDAO {
    private Connection conn;

    public PostDAO(Connection conn) {
        this.conn = conn;
    }

    // Method to add a new note
    public boolean addNotes(String title, String content, int userId) {
        boolean success = false;
        try {
            String query = "INSERT INTO post(title, content, uid) VALUES(?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, title);
            ps.setString(2, content);
            ps.setInt(3, userId);

            int result = ps.executeUpdate();
            if (result == 1) {
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // Method to get all notes by user ID
    public List<Post> getData(int userId) {
        List<Post> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM post WHERE uid=? ORDER BY id DESC";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);

            System.out.println("Executing query: " + ps.toString()); // Debugging

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Post post = new Post();
                post.setId(rs.getInt("id"));
                post.setTitle(rs.getString("title"));
                post.setContent(rs.getString("content"));
                post.setPdate(rs.getTimestamp("pdate")); // Fixed case sensitivity

                System.out.println("Fetched Note: " + post.getId() + " - " + post.getTitle()); // Debugging

                list.add(post);
            }

            System.out.println("Total notes found: " + list.size()); // Debugging

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Method to get a single note by its ID
    public Post getDataById(int noteId) {
        Post post = null;
        try {
            String query = "SELECT * FROM post WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, noteId);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                post = new Post();
                post.setId(rs.getInt("id"));
                post.setTitle(rs.getString("title")); // Fixed `getNString()`
                post.setContent(rs.getString("content"));
                post.setPdate(rs.getTimestamp("pdate"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return post;
    }

    // Method to update a note
    public boolean updatePost(int noteId, String title, String content) {
        boolean success = false;
        try {
            String query = "UPDATE post SET title=?, content=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, title);
            ps.setString(2, content);
            ps.setInt(3, noteId);

            int result = ps.executeUpdate();
            if (result == 1) {
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // Method to delete a note
    public boolean deleteNote(int noteId) {
        boolean success = false;
        try {
            String query = "DELETE FROM post WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, noteId);
            
            int result = ps.executeUpdate();
            if (result == 1) {
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }
}
